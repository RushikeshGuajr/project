﻿(function () {
    "use strict";    
    var app = angular.module('jobsearch', []);
    app.controller('jobsearchMainController', function ($scope,$http) {

        $scope.user = "Rushikesh";

        $("#myBooks").autocomplete({
            source: function (request, response) {

                var val = request.term;

                $.ajax({
                    url: "/api/City/Search",
                    type: "GET",
                    data: { search : val},
                    success: function (data) {
                        response($.map(data, function (item) {

                            return { value: item };
                        }));

                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert(textStatus);
                    }
                });
            },
            minLength: 1   // MINIMUM 1 CHARACTER TO START WITH.
        });
        $scope.resultJobs = null;

       
        $scope.searchCity = function (value) {
            $.ajax({
                url: "/api/City/getCityJobs",
                type: "GET",
                data: { cityName: value },
                success: function (data) {
                    if (data.result !== null) {
                        $scope.resultJobs = data.result;

                        return $scope.resultJobs;
                    }
                    else {
                        $scope.resultJobs = null;
                    }
                }
            });

            $http({
                method: 'GET',
                url: '/api/City/getCityJobs'
                
                
            }).then(function (response)  {
                // With the data succesfully returned, call our callback
                $scope.resultJobs = null;
                             
            }).error(function () {
                alert("error");
            });
            
        };
       
    });
})();