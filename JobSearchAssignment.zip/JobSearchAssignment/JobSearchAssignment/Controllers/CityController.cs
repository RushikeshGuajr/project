﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JobSearchAssignment.Models;
using Microsoft.AspNetCore.Mvc;

namespace JobSearchAssignment.Controllers
{
    public class CityController : Controller
    {

        

        public List<CityModel> CreateCityList()
        {
            var cityList = new List<CityModel>();

            CityModel c1 = new CityModel();
            c1.CityName = "Pune City";
            c1.CityId = 1;
            cityList.Add(c1);
            CityModel c2 = new CityModel();
            c2.CityName = "Mumbai City";
            c2.CityId = 2;
            cityList.Add(c2);
            CityModel c3 = new CityModel();
            c3.CityName = "Chennai City";
            c3.CityId = 3;
            cityList.Add(c3);
            CityModel c4 = new CityModel();
            c4.CityName = "New Delhi";
            c4.CityId = 4;
            cityList.Add(c4);
            CityModel c5 = new CityModel();
            c5.CityName = "London";
            c5.CityId = 5;
            cityList.Add(c5);
            CityModel c6 = new CityModel();
            c6.CityName = "NewYork";
            c6.CityId = 6;
            cityList.Add(c6);
            CityModel c7 = new CityModel();
            c7.CityName = "Prague";
            c7.CityId = 7;
            cityList.Add(c7);
            CityModel c8 = new CityModel();
            c8.CityName = "Luncknow";
            c8.CityId = 8;
            cityList.Add(c8);
            CityModel c9 = new CityModel();
            c9.CityName = "Mysore";
            c9.CityId = 9;
            cityList.Add(c9);
            CityModel c10 = new CityModel();
            c10.CityName = "California";
            c10.CityId = 10;
            cityList.Add(c10);

            return cityList;
        }
        


        [HttpGet("api/City/Search")]
        public List<String> AutoComplete(string search)
        {
            List<CityModel> list = CreateCityList();

            if (search != null)
            {
                var result = from l in list
                             where l.CityName.Contains(search)
                             select l.CityName;
                if (result != null)
                {
                    return result.ToList();
                }
                
                
            }
            return null;
        }

        [HttpGet("api/City/getCityJobs")]
        public JsonResult GetCityJobs(string cityName)
        {
            List<Jobs> list = CreateJobList();
            List<CityModel> cityList = CreateCityList();

            var getCityId = cityList.Where(c => c.CityName == cityName).Select(x=>x.CityId).FirstOrDefault();

            if (getCityId!=0)
            {
                var result = list.Where(j => j.CityId == Convert.ToInt32(getCityId));
                return Json(new { result });
            }


         return null;
        }

        public List<Jobs> CreateJobList()
        {
            var cityList = new List<Jobs>() { new Jobs {
                JobTitle = "WebMethod",
                JobDescription="WebMethod Developer opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=10,
                JobId=1
            },
            new Jobs {
                JobTitle = "Java Developer",
                JobDescription="Core Java Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=10,
                JobId=2
            },
            new Jobs {
                JobTitle = "FullStack",
                JobDescription="Fullstack Developer opening in Finance",
                WorkExp="2-5 Years Exp",
                CityId=1,
                JobId=3
            },
            new Jobs {
                JobTitle = "Java Developer",
                JobDescription="Core Java Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=9,
                JobId=1
            },
            new Jobs {
                JobTitle = "WebMethod",
                JobDescription="WebMethod Developer opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=3,
                JobId=1
            },
            new Jobs {
                JobTitle = "Java Developer",
                JobDescription="Core Java Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=4,
                JobId=1
            },
          new Jobs   {
                JobTitle = "WebMethod",
                JobDescription="WebMethod Developer opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=1,
                JobId=1
            },
            new Jobs {
                JobTitle = "Java Developer",
                JobDescription="Core Java Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=2,
                JobId=2
            },
            new Jobs {
                JobTitle = "FullStack",
                JobDescription="Fullstack Developer opening in Finance",
                WorkExp="2-5 Years Exp",
                CityId=3,
                JobId=3
            },
            new Jobs {
                JobTitle = "Java Developer",
                JobDescription="Core Java Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=4,
                JobId=1
            },
            new Jobs {
                JobTitle = "WebMethod",
                JobDescription="WebMethod Developer opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=5,
                JobId=1
            },
            new Jobs {
                JobTitle = "Java Developer",
                JobDescription="Core Java Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=6,
                JobId=1
            },
          new Jobs  {
                JobTitle = "Dot Net",
                JobDescription="Dot Net Developer opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=10,
                JobId=1
            },
            new Jobs {
                JobTitle = "ETL Developer",
                JobDescription="ETL Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=10,
                JobId=2
            },
            new Jobs {
                JobTitle = "SAP",
                JobDescription="SAP opening in Finance",
                WorkExp="2-5 Years Exp",
                CityId=1,
                JobId=3
            },
            new Jobs {
                JobTitle = "DevOps",
                JobDescription="DevOps opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=9,
                JobId=1
            },
            new Jobs {
                JobTitle = "Automation Testing",
                JobDescription="Automation Testing opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=3,
                JobId=1
            },
            new Jobs {
                JobTitle = "Tech Arch",
                JobDescription="Tech Arch opening in Finance Domain",
                WorkExp="10-13 Years Exp",
                CityId=4,
                JobId=1
            },
            new Jobs  {
                JobTitle = "Dot Net",
                JobDescription="Dot Net Developer opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=1,
                JobId=1
            },
            new Jobs {
                JobTitle = "ETL Developer",
                JobDescription="ETL Developer opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=2,
                JobId=2
            },
            new Jobs {
                JobTitle = "SAP",
                JobDescription="SAP opening in Finance",
                WorkExp="2-5 Years Exp",
                CityId=3,
                JobId=3
            },
            new Jobs {
                JobTitle = "DevOps",
                JobDescription="DevOps opening in Finance Domain",
                WorkExp="2-5 Years Exp",
                CityId=4,
                JobId=1
            },
            new Jobs {
                JobTitle = "Automation Testing",
                JobDescription="Automation Testing opening in Logistic",
                WorkExp="2-5 Years Exp",
                CityId=5,
                JobId=1
            },
            new Jobs {
                JobTitle = "Tech Arch",
                JobDescription="Tech Arch opening in Finance Domain",
                WorkExp="10-13 Years Exp",
                CityId=6,
                JobId=1
            }
            };

            return cityList;
        }
    }
}