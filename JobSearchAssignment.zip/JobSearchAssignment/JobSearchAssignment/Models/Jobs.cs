﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace JobSearchAssignment.Models
{
    public class Jobs
    {
        [Key]
        public int JobId { get; set; }

        public string JobDescription { get; set; }

      
        public int CityId { get; set; }
        [ForeignKey("CityId")]
        public CityModel city { get; set; }

        public string WorkExp { get; set; }

        public string JobTitle { get; set; }


    }
}
